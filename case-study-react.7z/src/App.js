import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import JwPagination from 'jw-react-pagination';
import getSymbolFromCurrency from 'currency-symbol-map'
import $ from "jquery";
import axios from "axios";
import ReactDOM from 'react-dom';

const HOST = "http://10.102.52.204:3000";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      products: [],
      pageOfItems: []
    };
  }
  componentWillMount() {
    var url = HOST + `/products/display`;
    axios.get(url).then(response => {
      this.setState({ products: response.data });
    });
  }
  onChangePage(pageOfItems) {
    // update local state with new page of items
    this.setState({ pageOfItems });
  }

  handleSubmitAddProduct(e) {
    e.preventDefault();
    // console.log("data submited is " + this.refs.addProdId.value);
    // alert("Product added with product id: "+this.refs.addProdId.value);
    axios.post(HOST + '/products/create', {
      productId: parseInt(this.refs.addProdId.value),
      productName: this.refs.addProdName.value,
      productDescription: this.refs.addProdDescription.value,
      productPrice: parseInt(this.refs.addProdPrice.value)
    }).then(response => {
      this.setState({ products: response.data });
    }).catch(function (error) {
      console.log(error);
    });

    this.refs.addProdId.value = null;
    this.refs.addProdName.value = null;
    this.refs.addProdDescription.value = null;
    this.refs.addProdPrice.value = null;
    alert("Product added Successfully");
  }

  handleDeleteProduct(id, e) {
    e.preventDefault();
    axios.post(HOST + '/products/pdelete', {
      productId: parseInt(id),
    }).then(response => {
      this.setState({ products: response.data });
    }).catch(function (error) {
      console.log(error);
    });
  }

  handleEditProduct(id, e) {
    var editProduct;
    for (let product of this.state.products) {
      if (product.productId === id) {
        editProduct = product;
      }
    }
    this.refs.editProdId.value = editProduct.productId;
    this.refs.editProdName.value = editProduct.productName;
    this.refs.editProdDescription.value = editProduct.productDescription;
    this.refs.editProdPrice.value = editProduct.productPrice;
  }

  handleEditProductSave(e) {
    e.preventDefault();
    // console.log("data submited is " + this.refs.addProdId.value);
    // alert("Product added with product id: "+this.refs.addProdId.value);
    axios.post(HOST + '/products/update', {
      productId: parseInt(this.refs.editProdId.value),
      productName: this.refs.editProdName.value,
      productDescription: this.refs.editProdDescription.value,
      productPrice: parseInt(this.refs.editProdPrice.value)
    }).then(response => {
      this.setState({ products: response.data });
    }).catch(function (error) {
      console.log(error);
    });
    alert("product details updated successfully");
  }


  handleDeleteAllProduct(e) {
    e.preventDefault();
    if (window.confirm("Are you sure??")) {
      axios.delete(HOST + '/products/deleteall').then(response => {
        this.setState({ products: response.data });
      }).catch(function (error) {
        console.log(error);
      });
    };
  }

  render() {
    // var productItem = this.state.products.map(product => {
    //   return <tr><td>{product.id}</td><td>{product.Name}</td><td>{product.Description}</td><td>{product.Price}</td><td><input type="button" className="btn btn-success" value="edit" />  <input type="button" className="btn btn-danger" value="delete" /></td></tr>
    // });
    return (
      <div>
        <h1 className="App">Welcome to Product Application</h1>
        <h1 className="App">Product List</h1>
        <br />
        <div className="container">
          <table className="App table table-striped table-bordered table-hover">
            <thead>
              <tr>
                <th className="col-md-1 text-center">Id</th>
                <th className="col-md-2 text-center">Name</th>
                <th className="col-md-6 text-center">Description</th>
                <th className="col-md-1 text-center">Price</th>
                <th colSpan="2" className="col-md-2 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {this.state.pageOfItems.map(product =>
                <tr key={product.productId}>
                  <td>{product.productId}</td>
                  <td>{product.productName}</td>
                  <td>{product.productDescription}</td>
                  <td>{getSymbolFromCurrency('USD')}{product.productPrice}</td>
                  <td> <button type="button" className="btn btn-info btn-block" data-toggle="modal" data-target="#editModal" onClick={this.handleEditProduct.bind(this, product.productId)}>Edit</button></td>
                  <td><button type="button" className="btn btn-danger btn-block" onClick={this.handleDeleteProduct.bind(this, product.productId)}>Delete</button></td>
                </tr>
              )}
            </tbody>
          </table>
          <JwPagination items={this.state.products} onChangePage={this.onChangePage.bind(this)} />
        </div>
        <div className="text-center">
          <button type="button" className="btn btn-success" data-toggle="modal" data-target="#addModal">Add Product</button>
          <button style={{ marginLeft: '5px' }} type="button" className="btn btn-danger" onClick={this.handleDeleteAllProduct.bind(this)}>Delete All Products</button>
        </div>
        {/*Add Product Model*/}
        <div className="modal fade" id="addModal">
          <div className="modal-dialog ">
            <div className="modal-content">
              {/*Model Header*/}
              <div className="modal-header">
                <h4 className="modal-title">Add Product
                  <button type="button" className="close" data-dismiss="modal">&times;</button>
                </h4>
              </div>
              {/*model body*/}
              <div className="modal-body">
                <form className="form-horizontal" onSubmit={this.handleSubmitAddProduct.bind(this)}>
                  <div className="form-group">
                    <label className="control-label col-sm-2" >ID:</label>
                    <div className="col-sm-10">
                      <input type="text" className="form-control" ref="addProdId" name="id" required pattern="[0-9]{4}" title="Id Should not be null and of 4 digits" />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="control-label col-sm-2" >Name:</label>
                    <div className="col-sm-10">
                      <input type="text" className="form-control" ref="addProdName" name="name" required pattern="[A-Z][A-Za-z0-9_ ]*" title="Product Name should start with Capital letter" />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="control-label col-sm-2" >Description:</label>
                    <div className="col-sm-10">
                      <input type="text" className="form-control" ref="addProdDescription" name="desc" required />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="control-label col-sm-2" >Price:</label>
                    <div className="col-sm-10">
                      <input type="number" className="form-control" ref="addProdPrice" name="price" required />
                    </div>
                  </div>
                  <input type="submit" className="btn btn-info" value="Submit" />&nbsp;
                  {/*<button type="submit" className="btn btn-info" data-dismiss="modal" >Submit</button>&nbsp;*/}
                  <button className="btn btn-warning" data-dismiss="modal">Cancel</button>
                </form>
              </div>
            </div>
          </div>
        </div>


        {/*Edit Product Model*/}
        <div className="modal fade" id="editModal">
          <div className="modal-dialog ">
            <div className="modal-content">
              {/*<!-- Modal Header -->*/}
              <div className="modal-header">
                <h4 className="modal-title">Edit Product
                  <button type="button" className="close" data-dismiss="modal">&times;</button>
                </h4>
              </div>
              {/*<!-- Modal body -->*/}
              <div className="modal-body">
                <form className="form-horizontal" onSubmit={this.handleEditProductSave.bind(this)}>
                  <div className="form-group">
                    <label className="control-label col-sm-2" >ID:</label>
                    <div className="col-sm-10">
                      <input type="number" className="form-control" ref="editProdId" disabled name="id" required pattern="[0-9]{4}" title="Id Should not be null and of 4 digits" />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="control-label col-sm-2" >Name:</label>
                    <div className="col-sm-10">
                      <input type="text" className="form-control" ref="editProdName" name="name" required pattern="[A-Z][A-Za-z0-9_ ]*" title="Product Name should start with Capital letter" />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="control-label col-sm-2">Description:</label>
                    <div className="col-sm-10">
                      <input type="text" className="form-control" ref="editProdDescription" name="desc" required />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="control-label col-sm-2" >Price:</label>
                    <div className="col-sm-10">
                      <input type="text" className="form-control" ref="editProdPrice" name="price" required />
                    </div>
                  </div>
                  <button type="submit" className="btn btn-info">Submit</button>&nbsp;
                  <button className="btn btn-warning" data-dismiss="modal">Cancel</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default App;
